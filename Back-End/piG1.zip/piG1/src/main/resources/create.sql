
create table IF NOT EXISTS categorias(id int auto_increment primary key,titulo varchar(255),descripcion varchar (255),url varchar(255));